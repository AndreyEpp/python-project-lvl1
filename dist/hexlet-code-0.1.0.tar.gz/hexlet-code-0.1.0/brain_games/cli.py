import prompt


def welcome_user():
    name = prompt.string(f'May I have your name? ')
    answer = prompt.string(f'Your answer: ')
